(function () {
	var arr = [1,2,3,4,5].map(function (item, index) {
		return item + 10;
	});
	console.log(arr);
})();