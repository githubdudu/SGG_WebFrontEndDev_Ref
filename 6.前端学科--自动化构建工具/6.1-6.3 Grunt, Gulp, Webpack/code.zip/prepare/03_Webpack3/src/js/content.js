export function fun(x) {
  return x * x;
}

export function fun2(x) {
  return x ** x;
}