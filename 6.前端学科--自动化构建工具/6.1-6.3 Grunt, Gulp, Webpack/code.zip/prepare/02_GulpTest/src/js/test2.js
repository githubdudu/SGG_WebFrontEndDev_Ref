(function () {
	var arr = [2,3,4].map(function (item, index) {
		return item+1;
	});
	console.log(arr);
})();