export default {
  name: 'Tom',
  setName: function (name) {
    this.name = name
  }
}