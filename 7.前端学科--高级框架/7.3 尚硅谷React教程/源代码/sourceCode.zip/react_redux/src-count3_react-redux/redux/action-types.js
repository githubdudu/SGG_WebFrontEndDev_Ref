export const INCREMENT = 'increment'
export const DECREMENT = 'decrement'