/*
包含所有action type的常量字符串
 */
export const INCREMENT = 'INCREMENT'
export const DECREMENT = 'DECREMENT'
export const ADD_MSG = 'ADD_MSG'